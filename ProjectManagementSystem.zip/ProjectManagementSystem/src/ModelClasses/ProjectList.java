public class ProjectList
{    //sorry haven't started this yet
  public ProjectList(){

  }
  public Project getProjectByTitle(String title){
    return null;
  }
  public Project getEndedProjectByTitle(String title){
    return null;
  }
  public void addProject(String title,Date deadline,String comment){

  }
  public void removeProject(String title){

  }
  public ArrayList<Project> getAllProjects(Status status){

    return null;
}
}
