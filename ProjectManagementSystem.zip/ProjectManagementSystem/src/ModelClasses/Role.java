public enum Role {
    TeamMember, ProjectManager, ScrumMaster;
}
