package ModelClasses;
import java.util.Date;

public class MyDate
{

}
